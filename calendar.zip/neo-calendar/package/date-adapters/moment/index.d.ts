import { DateAdapter } from '../date-adapter';
export declare function adapterFactory(moment: any): DateAdapter;
