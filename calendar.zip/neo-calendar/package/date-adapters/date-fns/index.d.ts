import { DateAdapter } from '../date-adapter';
export declare function adapterFactory(): DateAdapter;
