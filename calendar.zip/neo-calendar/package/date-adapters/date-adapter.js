"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var DateAdapter = /** @class */ (function () {
    function DateAdapter() {
    }
    return DateAdapter;
}());
exports.DateAdapter = DateAdapter;
//# sourceMappingURL=date-adapter.js.map