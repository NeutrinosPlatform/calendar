export { CalendarDayViewComponent, CalendarDayViewBeforeRenderEvent } from './calendar-day-view.component';
export declare class CalendarDayModule {
}
