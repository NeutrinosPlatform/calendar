export { CalendarWeekViewComponent, CalendarWeekViewBeforeRenderEvent } from './calendar-week-view.component';
export { WeekViewAllDayEvent as CalendarWeekViewAllDayEvent, WeekViewAllDayEventRow as CalendarWeekViewAllDayEventRow, GetWeekViewArgs as CalendarGetWeekViewArgs } from 'calendar-utils';
export { getWeekViewPeriod } from '../common/util';
export declare class CalendarWeekModule {
}
