export { CalendarMonthViewComponent, CalendarMonthViewBeforeRenderEvent, CalendarMonthViewEventTimesChangedEvent } from './calendar-month-view.component';
export { MonthViewDay as CalendarMonthViewDay } from 'calendar-utils';
export { collapseAnimation } from './calendar-open-day-events.component';
export declare class CalendarMonthModule {
}
