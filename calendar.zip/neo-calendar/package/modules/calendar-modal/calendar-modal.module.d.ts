export { CalendarModalComponent } from './calendar-modal.component';
export declare class CalendarCommonModalModule {
}
