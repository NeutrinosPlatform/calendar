export { CalendarCommonHeaderComponent } from './calendar-header.component';
export declare class CalendarCommonHeaderModule {
}
