/*
 * Public API Surface of angular-calendar
 */

export * from './modules/calendar.module';
