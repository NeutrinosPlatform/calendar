import { adapterFactory as baseAdapterFactory } from 'calendar-utils/date-adapters/date-fns';
import { addWeeks, addMonths, subDays, subWeeks, subMonths, getISOWeek, setDate, setMonth, setYear, getDate, getYear } from 'date-fns';
export function adapterFactory() {
    return Object.assign({}, baseAdapterFactory(), { addWeeks,
        addMonths,
        subDays,
        subWeeks,
        subMonths,
        getISOWeek,
        setDate,
        setMonth,
        setYear,
        getDate,
        getYear });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290Ijoibmc6Ly9uZW8tY2FsZW5kYXIvIiwic291cmNlcyI6WyJkYXRlLWFkYXB0ZXJzL2RhdGUtZm5zL2luZGV4LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxjQUFjLElBQUksa0JBQWtCLEVBQUUsTUFBTSx1Q0FBdUMsQ0FBQztBQUM3RixPQUFPLEVBQ0wsUUFBUSxFQUNSLFNBQVMsRUFDVCxPQUFPLEVBQ1AsUUFBUSxFQUNSLFNBQVMsRUFDVCxVQUFVLEVBQ1YsT0FBTyxFQUNQLFFBQVEsRUFDUixPQUFPLEVBQ1AsT0FBTyxFQUNQLE9BQU8sRUFDUixNQUFNLFVBQVUsQ0FBQztBQUdsQixNQUFNLFVBQVUsY0FBYztJQUM1Qix5QkFDSyxrQkFBa0IsRUFBRSxJQUN2QixRQUFRO1FBQ1IsU0FBUztRQUNULE9BQU87UUFDUCxRQUFRO1FBQ1IsU0FBUztRQUNULFVBQVU7UUFDVixPQUFPO1FBQ1AsUUFBUTtRQUNSLE9BQU87UUFDUCxPQUFPO1FBQ1AsT0FBTyxJQUNQO0FBQ0osQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGFkYXB0ZXJGYWN0b3J5IGFzIGJhc2VBZGFwdGVyRmFjdG9yeSB9IGZyb20gJ2NhbGVuZGFyLXV0aWxzL2RhdGUtYWRhcHRlcnMvZGF0ZS1mbnMnO1xuaW1wb3J0IHtcbiAgYWRkV2Vla3MsXG4gIGFkZE1vbnRocyxcbiAgc3ViRGF5cyxcbiAgc3ViV2Vla3MsXG4gIHN1Yk1vbnRocyxcbiAgZ2V0SVNPV2VlayxcbiAgc2V0RGF0ZSxcbiAgc2V0TW9udGgsXG4gIHNldFllYXIsXG4gIGdldERhdGUsXG4gIGdldFllYXJcbn0gZnJvbSAnZGF0ZS1mbnMnO1xuaW1wb3J0IHsgRGF0ZUFkYXB0ZXIgfSBmcm9tICcuLi9kYXRlLWFkYXB0ZXInO1xuXG5leHBvcnQgZnVuY3Rpb24gYWRhcHRlckZhY3RvcnkoKTogRGF0ZUFkYXB0ZXIge1xuICByZXR1cm4ge1xuICAgIC4uLmJhc2VBZGFwdGVyRmFjdG9yeSgpLFxuICAgIGFkZFdlZWtzLFxuICAgIGFkZE1vbnRocyxcbiAgICBzdWJEYXlzLFxuICAgIHN1YldlZWtzLFxuICAgIHN1Yk1vbnRocyxcbiAgICBnZXRJU09XZWVrLFxuICAgIHNldERhdGUsXG4gICAgc2V0TW9udGgsXG4gICAgc2V0WWVhcixcbiAgICBnZXREYXRlLFxuICAgIGdldFllYXJcbiAgfTtcbn1cbiJdfQ==