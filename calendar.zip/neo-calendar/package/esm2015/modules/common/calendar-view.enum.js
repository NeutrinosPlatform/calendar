export var CalendarView;
(function (CalendarView) {
    CalendarView["Month"] = "month";
    CalendarView["Week"] = "week";
    CalendarView["Day"] = "day";
})(CalendarView || (CalendarView = {}));
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2FsZW5kYXItdmlldy5lbnVtLmpzIiwic291cmNlUm9vdCI6Im5nOi8vbmVvLWNhbGVuZGFyLyIsInNvdXJjZXMiOlsibW9kdWxlcy9jb21tb24vY2FsZW5kYXItdmlldy5lbnVtLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE1BQU0sQ0FBTixJQUFZLFlBSVg7QUFKRCxXQUFZLFlBQVk7SUFDdEIsK0JBQWUsQ0FBQTtJQUNmLDZCQUFhLENBQUE7SUFDYiwyQkFBVyxDQUFBO0FBQ2IsQ0FBQyxFQUpXLFlBQVksS0FBWixZQUFZLFFBSXZCIiwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGVudW0gQ2FsZW5kYXJWaWV3IHtcbiAgTW9udGggPSAnbW9udGgnLFxuICBXZWVrID0gJ3dlZWsnLFxuICBEYXkgPSAnZGF5J1xufVxuIl19